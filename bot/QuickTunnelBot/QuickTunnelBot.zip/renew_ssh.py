#!/usr/bin/env python3
import telebot
from datetime import datetime, timedelta
import subprocess
from telebot import types

def get_ssh_users():
    users = []
    try:
        # Get all users with UID >= 1000 (normal users)
        output = subprocess.check_output("getent passwd | awk -F: '$3 >= 1000 && $3 != 65534 {print $1}'", shell=True)
        users = output.decode().splitlines()
    except subprocess.CalledProcessError:
        pass
    return users

def get_user_expiry(username):
    try:
        output = subprocess.check_output(f"chage -l {username}", shell=True)
        for line in output.decode().splitlines():
            if "Account expires" in line:
                return line.split(": ")[1].strip()
    except subprocess.CalledProcessError:
        return "Never"
    return "Never"

def renew_user(username, days):
    expiry_date = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
    try:
        subprocess.run(f"chage -E {expiry_date} {username}", shell=True, check=True)
        return expiry_date
    except subprocess.CalledProcessError:
        return None

def renew_ssh(bot, message):
    chat_id = message.chat.id
    users = get_ssh_users()
    
    if not users:
        bot.reply_to(message, "No SSH users found.")
        return
    
    # Create user list text
    user_list = "┌──────────────────┐\n"
    user_list += "    .:: RENEW SSH ACCOUNT ::.    \n"
    user_list += "└──────────────────┘\n"
    
    for i, user in enumerate(users, 1):
        exp = get_user_expiry(user)
        user_list += f"  {i:2}. {user:7} | <code>{exp:16}</code>\n"
    
    user_list += "───────────────────\n"
    user_list += "Input user number to select!"
    
    msg = bot.send_message(chat_id, user_list, parse_mode='HTML')
    bot.register_next_step_handler(msg, process_user_selection, users, bot)

def process_user_selection(message, users, bot):
    chat_id = message.chat.id
    try:
        user_num = int(message.text)
        
        if 1 <= user_num <= len(users):
            username = users[user_num - 1]
            msg = bot.send_message(chat_id, f"Input new expired days!")
            bot.register_next_step_handler(msg, process_days_selection, username, bot)
        else:
            msg = bot.send_message(chat_id, "Invalid user number. Please enter a valid number from the list.")
            bot.register_next_step_handler(msg, process_user_selection, users)
    except ValueError:
        msg = bot.send_message(chat_id, "Please enter a valid number.")
        bot.register_next_step_handler(msg, process_user_selection, users)

def process_days_selection(message, username, bot):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    
    markup.add(sub1)

    chat_id = message.chat.id
    try:
        days = int(message.text)
        if 1 <= days <= 365:
            new_expiry = renew_user(username, days)
            
            if new_expiry:
                response = f"""
 ✅ RENEWAL SUCCESSFUL   
─────────────────
User: {username}
New Expiry: {new_expiry}
─────────────────
"""
                bot.send_message(chat_id, response, reply_markup=markup)
            else:
                bot.send_message(chat_id, "Failed to renew user. Please try again.")
        else:
            msg = bot.send_message(chat_id, "Please enter a number between 1 and 365.")
            bot.register_next_step_handler(msg, process_days_selection, username)
    except ValueError:
        msg = bot.send_message(chat_id, "Please enter a valid number between 1 and 365.")
        bot.register_next_step_handler(msg, process_days_selection, username)

