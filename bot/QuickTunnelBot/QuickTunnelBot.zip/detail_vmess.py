import telebot
import os
from telebot import types

# Replace with your actual Telegram bot token
TOKEN = '7951780731:AAHneora9mPywHJsGNbg9pCAKGdbNJyZ0HM'
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "Welcome to Vmess Account Details Bot!\nUse /list to see available accounts.")

@bot.message_handler(commands=['list'])
def list_vmess_accounts(message):
    folder = "/etc/xray/history/"
    
    if not os.path.exists(folder):
        bot.reply_to(message, "Error: Folder not found!")
        return
    
    try:
        files = [f for f in os.listdir(folder) if f.startswith('vmess-') and os.path.isfile(os.path.join(folder, f))]
        
        if not files:
            bot.reply_to(message, "No account found.")
            return
            
        # Create a numbered list of accounts
        account_list = "\n".join([f"  {i}. {filename[6:]}" for i, filename in enumerate(files, 1)])
        
        response = "┌──────────────────┐\n"
        response += "   .:: VIEW DETAIL ACCOUNT ::. \n"
        response += "└──────────────────┘\n"
        response +=  account_list + "\n"
        response += "└──────────────────┘\n"
        response += "Input user number to select! \n"

        # Send the list as a message
        msg = bot.reply_to(message, f"{response}")
        
        # Register the next step handler
        bot.register_next_step_handler(msg, process_account_selection, files)
        
    except Exception as e:
        bot.reply_to(message, f"Error: {str(e)}")

def process_account_selection(message, files):
    try:
        # Get the user's selection
        selection = message.text.strip()
        
        if not selection.isdigit():
            bot.reply_to(message, "Invalid input! Please enter a number.")
            return
            
        index = int(selection) - 1
        
        if 0 <= index < len(files):
            folder = "/etc/xray/history/"
            selected_file = os.path.join(folder, files[index])
            with open(selected_file, 'r') as f:
                content = f.read()
            
            # Send the content (consider splitting if too long)
            bot.reply_to(message, f"{content}")
        else:
            bot.reply_to(message, "Invalid number! Please select a number from the list.")
            
    except Exception as e:
        bot.reply_to(message, f"Error: {str(e)}")
