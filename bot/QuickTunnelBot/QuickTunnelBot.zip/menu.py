import telebot
import subprocess
import json
from telebot import types
from create_trial_ssh import create_ssh, trial_ssh
from delete_ssh import delete_ssh, handle_confirmation
from renew_ssh import renew_ssh
from detail_ssh import detail_ssh
from create_vmess import create_vmess
from delete_vmess import delete_vmess, handle_confirmation_vmess
from renew_vmess import renew_vmess
from trial_vmess import trial_vmess


# === Token Bot ===
TOKEN = '7951780731:AAHneora9mPywHJsGNbg9pCAKGdbNJyZ0HM'
bot = telebot.TeleBot(TOKEN)

# === Chat ID yang diizinkan mengakses bot ===
AUTHORIZED_CHAT_ID = 576495165  # Ganti dengan chat ID Anda

# === Fungsi untuk Jalankan Shell Command ===
def shell_exec(cmd):
    try:
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode('utf-8').strip()
        return output.split('\n')[0]  # Ambil hanya baris pertama
    except:
        return ""

# === Ambil Informasi Server ===
def get_server_info():
    os_pretty = shell_exec("grep -E '^PRETTY_NAME=' /etc/os-release | cut -d= -f2 | tr -d '\"'")
    ip = shell_exec("curl -s ifconfig.me")

    # Default values
    isp = 'Unknown'
    country = 'Unknown'
    city = 'Unknown'

    # Menggunakan hanya ip-api.com
    try:
        raw_data = shell_exec("curl -s http://ip-api.com/json/")
        if raw_data:
            data = json.loads(raw_data)
            if data.get('status') == 'success':
                isp = data.get('isp', isp)
                country = data.get('country', country)
                city = data.get('city', city)
    except:
        pass

    domain = shell_exec("cat /etc/xray/domain 2>/dev/null || echo 'Not Found'")
    version = shell_exec("cat /etc/xray/version 2>/dev/null || echo 'Not Found'")

    # Hitung jumlah akun
    vmess_count = shell_exec("grep -c '##' /etc/xray/config.json 2>/dev/null || echo 0")
    vless_count = shell_exec("grep -c '#?' /etc/xray/config.json 2>/dev/null || echo 0")
    trojan_count = shell_exec("grep -c '#!' /etc/xray/config.json 2>/dev/null || echo 0")
    ssh_count = shell_exec("awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd | wc -l")

    return {
        'os': os_pretty,
        'ip': ip,
        'isp': isp,
        'country': country,
        'city': city,
        'domain': domain,
        'version': version,
        'vmess': int(vmess_count) // 2 if vmess_count.isdigit() else 0,
        'vless': int(vless_count) // 2 if vless_count.isdigit() else 0,
        'trojan': int(trojan_count) // 2 if trojan_count.isdigit() else 0,
        'ssh': int(ssh_count) if ssh_count.isdigit() else 0,
    }

# === Handler untuk Perintah /start ===
@bot.message_handler(commands=['start'])
def send_welcome(message):
    if message.chat.id != AUTHORIZED_CHAT_ID:
        bot.reply_to(message, "❌ Anda tidak memiliki akses ke bot ini.")
        return

    info = get_server_info()

    # Format region
    region = info['country']
    if info['city'] != 'Unknown':
        region = f"{info['city']}, {info['country']}"

    status_text = f"""🖥️ *Server Information* 🖥️
─────────────────────
*OS System :* `{info['os']}`
*ISP :* `{info['isp']}`
*Region :* `{region}`
*IP :* `{info['ip']}`
*Domain :* `{info['domain']}`
*XRay Version :* `{info['version']}`

🔐 *Jumlah Akun Aktif* 🔐
*SSH* : `{info['ssh']}`
*Vmess* : `{info['vmess']}`
*Vless* : `{info['vless']}`
*Trojan* : `{info['trojan']}`
─────────────────────"""

    # Membuat markup inline keyboard
    markup = telebot.types.InlineKeyboardMarkup(row_width=2)
    btn_ssh = telebot.types.InlineKeyboardButton("MENU SSH", callback_data='menu_ssh')
    btn_vmess = telebot.types.InlineKeyboardButton("MENU VMESS", callback_data='menu_vmess')
    btn_vless = telebot.types.InlineKeyboardButton("MENU VLESS", callback_data='menu_vless')
    btn_trojan = telebot.types.InlineKeyboardButton("MENU TROJAN", callback_data='menu_trojan')
    btn_lain = telebot.types.InlineKeyboardButton("MENU LAIN", callback_data='menu_lain')

    markup.add(btn_ssh, btn_vmess)
    markup.add(btn_vless, btn_trojan)
    markup.add(btn_lain)

    bot.send_message(message.chat.id, status_text, reply_markup=markup, parse_mode='Markdown')

# === Handler untuk Callback Inline Button ===
@bot.callback_query_handler(func=lambda call: True)
def handle_callback_query(call):
    if call.message.chat.id != AUTHORIZED_CHAT_ID:
        bot.answer_callback_query(call.id, "Anda tidak memiliki akses.")
        return

    data = call.data

    if data == 'menu_ssh':
        menu_ssh(call)
    elif data == 'menu_vmess':
        menu_vmess(call)
    elif data == 'menu_vless':
        menu_vless(call)
    elif data == 'menu_trojan':
        menu_trojan(call)
    elif data == 'menu_lain':
        menu_lain(call)
    elif data == 'menu_utama':
        menu_utama(call)        
    # === Bagian Qallbackquerry Fungsi Menu ===
    elif data == 'create_ssh':
        create_ssh(bot, call.message)    
    elif data == 'trial_ssh':
        trial_ssh(bot, call.message)    
    elif call.data == "delete_ssh":
        delete_ssh(bot, call.message)
    elif call.data.startswith('confirm_yes_') or call.data.startswith('confirm_no_'):
        handle_confirmation(bot, call)
    elif call.data == "renew_ssh":
        renew_ssh(bot, call.message)
    elif call.data == "detail_ssh":
        detail_ssh(bot, call.message)
    # === Bagian Qallbackquerry Fungsi Menu ===
    elif data == 'create_vmess':
        create_vmess(bot, call.message)    
    elif call.data == "delete_vmess":
        delete_vmess(bot, call.message)
    elif call.data.startswith('confirm_delete_vmess') or call.data == "cancel_delete":
        handle_confirmation_vmess(bot, call)
    elif call.data == "renew_vmess":
        renew_vmess(bot, call.message)
    elif call.data == "trial_vmess":
        trial_vmess(bot, call.message)
        
        
# === MENU UTAMA ===
def menu_utama(call):
    
    info = get_server_info()

    # Format region
    region = info['country']
    if info['city'] != 'Unknown':
        region = f"{info['city']}, {info['country']}"

    status_text = f"""🖥️ *Server Information* 🖥️
─────────────────────
*OS System :* `{info['os']}`
*ISP :* `{info['isp']}`
*Region :* `{region}`
*IP :* `{info['ip']}`
*Domain :* `{info['domain']}`
*XRay Version :* `{info['version']}`

🔐 *Jumlah Akun Aktif* 🔐
*SSH* : `{info['ssh']}`
*Vmess* : `{info['vmess']}`
*Vless* : `{info['vless']}`
*Trojan* : `{info['trojan']}`
─────────────────────"""

    markup = telebot.types.InlineKeyboardMarkup(row_width=2)
    btn_ssh = telebot.types.InlineKeyboardButton("MENU SSH", callback_data='menu_ssh')
    btn_vmess = telebot.types.InlineKeyboardButton("MENU VMESS", callback_data='menu_vmess')
    btn_vless = telebot.types.InlineKeyboardButton("MENU VLESS", callback_data='menu_vless')
    btn_trojan = telebot.types.InlineKeyboardButton("MENU TROJAN", callback_data='menu_trojan')
    btn_lain = telebot.types.InlineKeyboardButton("MENU LAIN", callback_data='menu_lain')

    markup.add(btn_ssh, btn_vmess)
    markup.add(btn_vless, btn_trojan)
    markup.add(btn_lain)
    
    bot.edit_message_text(
            chat_id=call.message.chat.id, 
            message_id=call.message.message_id,
            text=status_text,
            reply_markup=markup,
            parse_mode='Markdown'
        ) 

# === MENU SSH ===
def menu_ssh(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    sub1 = types.InlineKeyboardButton("CREATE SSH", callback_data='create_ssh')
    sub2 = types.InlineKeyboardButton("DELETE SSH", callback_data='delete_ssh')
    sub3 = types.InlineKeyboardButton("RENEW SSH", callback_data='renew_ssh')
    sub4 = types.InlineKeyboardButton("DETAIL SSH", callback_data='detail_ssh')
    sub5 = types.InlineKeyboardButton("TRIAL SSH", callback_data='trial_ssh')
    sub6 = types.InlineKeyboardButton("MENU UTAMA", callback_data='menu_utama')
    
    markup.add(sub1, sub2, sub3, sub4, sub5)
    markup.add(sub6)
    
    massage_text = """📘 :: MENU SSH MANAGER :: 📘
─────────────────────
• Buat Akun SSH
• Hapus Akun SSH
• Perpanjang Akun SSH
• Lihat Detail SSH
• Trial SSH
─────────────────────"""
    
    bot.edit_message_text(
            chat_id=call.message.chat.id, 
            message_id=call.message.message_id,
            text=massage_text,
            reply_markup=markup,
            parse_mode='Markdown'
        ) 
        
# === MENU VMESS ===
def menu_vmess(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    sub1 = types.InlineKeyboardButton("CREATE VMESS", callback_data='create_vmess')
    sub2 = types.InlineKeyboardButton("DELETE VMESS", callback_data='delete_vmess')
    sub3 = types.InlineKeyboardButton("RENEW VMESS", callback_data='renew_vmess')
    sub4 = types.InlineKeyboardButton("DETAIL VMESS", callback_data='detail_vmess')
    sub5 = types.InlineKeyboardButton("TRIAL VMESS", callback_data='trial_vmess')
    sub6 = types.InlineKeyboardButton("MENU UTAMA", callback_data='menu_utama')
    
    markup.add(sub1, sub2, sub3, sub4, sub5)
    markup.add(sub6)
    
    massage_text = """📘 :: MENU VMESS MANAGER :: 📘
─────────────────────
• Buat Akun VMESS
• Hapus Akun VMESS
• Perpanjang Akun VMESS
• Lihat Detail VMESS
• Trial VMESS
─────────────────────"""
    
    bot.edit_message_text(
        chat_id=call.message.chat.id, 
        message_id=call.message.message_id,
        text=massage_text,
        reply_markup=markup,
        parse_mode='Markdown'
    )        
        
# === MENU VLESS ===
def menu_vless(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    sub1 = types.InlineKeyboardButton("CREATE VLESS", callback_data='create_vless')
    sub2 = types.InlineKeyboardButton("DELETE VLESS", callback_data='delete_vless')
    sub3 = types.InlineKeyboardButton("RENEW VLESS", callback_data='renew_vless')
    sub4 = types.InlineKeyboardButton("DETAIL VLESS", callback_data='detail_vless')
    sub5 = types.InlineKeyboardButton("TRIAL VLESS", callback_data='trial_vless')
    sub6 = types.InlineKeyboardButton("MENU UTAMA", callback_data='menu_utama')
    
    markup.add(sub1, sub2, sub3, sub4, sub5)
    markup.add(sub6)
    
    massage_text = """📘 :: MENU VLESS MANAGER :: 📘
─────────────────────
• Buat Akun VLESS
• Hapus Akun VLESS
• Perpanjang Akun VLESS
• Lihat Detail VLESS
• Trial VLESS
─────────────────────"""
    
    bot.edit_message_text(
        chat_id=call.message.chat.id, 
        message_id=call.message.message_id,
        text=massage_text,
        reply_markup=markup,
        parse_mode='Markdown'
    )    
    
# === MENU TROJAN ===
def menu_trojan(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    sub1 = types.InlineKeyboardButton("CREATE TROJAN", callback_data='create_trojan')
    sub2 = types.InlineKeyboardButton("DELETE TROJAN", callback_data='delete_trojan')
    sub3 = types.InlineKeyboardButton("RENEW TROJAN", callback_data='renew_trojan')
    sub4 = types.InlineKeyboardButton("DETAIL TROJAN", callback_data='detail_trojan')
    sub5 = types.InlineKeyboardButton("TRIAL TROJAN", callback_data='trial_trojan')
    sub6 = types.InlineKeyboardButton("MENU UTAMA", callback_data='menu_utama')
    
    markup.add(sub1, sub2, sub3, sub4, sub5)
    markup.add(sub6)
    
    massage_text = """📘 :: MENU TROJAN MANAGER :: 📘
─────────────────────
• Buat Akun TROJAN
• Hapus Akun TROJAN
• Perpanjang Akun TROJAN
• Lihat Detail TROJAN
• Trial TROJAN
─────────────────────"""
    
    bot.edit_message_text(
        chat_id=call.message.chat.id, 
        message_id=call.message.message_id,
        text=massage_text,
        reply_markup=markup,
        parse_mode='Markdown'
    ) 
    
# === MENU LAIN ===
def menu_lain(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    sub1 = types.InlineKeyboardButton("INFO SISTEM", callback_data='info_sistem')
    sub2 = types.InlineKeyboardButton("CEK PEMAKAIAN", callback_data='cek_penggunaan')
    sub3 = types.InlineKeyboardButton("BACKUP DATA", callback_data='backup_data')
    sub4 = types.InlineKeyboardButton("PENGATURAN BOT", callback_data='pengaturan_bot')
    sub5 = types.InlineKeyboardButton("KEMBALI", callback_data='kembali_ke_menu_utama')
    sub6 = types.InlineKeyboardButton("MENU UTAMA", callback_data='menu_utama')
    
    markup.add(sub1, sub2, sub3, sub4, sub5)
    markup.add(sub6)
    
    massage_text = """📘 :: MENU LAIN :: 📘
─────────────────────
• Info Sistem Server
• Cek Penggunaan Akun
• Backup Konfigurasi
• Pengaturan Bot
• Kembali ke Menu Utama
─────────────────────"""
    
    bot.edit_message_text(
        chat_id=call.message.chat.id, 
        message_id=call.message.message_id,
        text=massage_text,
        reply_markup=markup,
        parse_mode='Markdown'
    )    

# === Jalankan Bot ===
print("Bot sedang berjalan...")
bot.polling(none_stop=True)