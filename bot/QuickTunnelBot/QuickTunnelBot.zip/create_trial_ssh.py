import telebot
from datetime import datetime, timedelta
import subprocess
import os
import random
import string
from telebot import types


# Read domain from file
with open("/etc/xray/domain", "r") as f:
    domain = f.read().strip()

def generate_random_text(length=5):
    """Generate random text for username"""
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(length))

# Common utility functions
def user_exists(username):
    try:
        subprocess.check_output(["id", username], stderr=subprocess.STDOUT)
        return True
    except subprocess.CalledProcessError:
        return False

def create_user(username, password, expiry_date):
    # Create user with expiry date and /bin/false shell
    subprocess.run(["useradd", "-e", expiry_date, "-s", "/bin/false", "-M", username])
    
    # Set password
    proc = subprocess.Popen(["passwd", username], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    proc.communicate(input=f"{password}\n{password}\n".encode())

def get_expiry_date(username):
    output = subprocess.check_output(["chage", "-l", username]).decode()
    for line in output.splitlines():
        if "Account expires" in line:
            return line.split(":")[1].strip()
    return "Unknown"

def save_account_info(username, password, expiry_date):
    history_dir = "/etc/xray/history"
    if not os.path.exists(history_dir):
        os.makedirs(history_dir)
    
    filename = f"{history_dir}/ssh-{username}"
    with open(filename, "w") as f:
        f.write(f"""
✅ Akun SSH telah berhasil dibuat!
------------------------------------
Username : {username}
Password : {password}
Expired  : {expiry_date}
------------------------------------
Host : {domain}
Websocket : 80
Websocket (TLS): 443
BadVpn  : 7100-7900
------------------------------------
Websocket :
{domain}:80@{username}:{password}
Websocket TLS/SNI :
{domain}:443@{username}:{password}
------------------------------------
""")

def format_account_info(username, password, expiry_date, is_trial=False):
    """Format account information for display"""
    trial_note = "\nNote: This is a trial account valid for 1 day" if is_trial else ""
    
    return f"""
{'✅ Trial SSH Account has been created!' if is_trial else '✅ Akun SSH telah berhasil dibuat!'}
------------------------------------
Username : <code>{username}</code>
Password : <code>{password}</code>
Expired  : {expiry_date}
------------------------------------
Host : {domain}
Websocket : 80
Websocket (TLS): 443
BadVpn  : 7100-7900
------------------------------------
Websocket :
<code>{domain}:80@{username}:{password}</code>
Websocket TLS/SNI :
<code>{domain}:443@{username}:{password}</code>
------------------------------------
{trial_note}
"""

def trial_ssh(bot, message):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    
    markup.add(sub1)

    try:
        chat_id = message.chat.id
        username = f"Trial-{generate_random_text()}"
        password = "1"
        days = 1  # Trial period is 1 day
        expiry_date = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
        
        if user_exists(username):
            bot.send_message(chat_id, "❌ Error: Username already exists! Please try /trial again")
            return
            
        create_user(username, password, expiry_date)
        actual_expiry = get_expiry_date(username)
        save_account_info(username, password, actual_expiry)
        
        account_info = format_account_info(username, password, actual_expiry, is_trial=True)
       
        bot.edit_message_text(
                  chat_id=chat_id,
                  message_id=message.message_id,
                  text=account_info,
                  reply_markup=markup,
                  parse_mode='HTML'
        ) 
        
    except Exception as e:
        bot.reply_to(message, f"❌ Error creating trial account: {str(e)}")

def create_ssh(bot, message):
    msg = bot.send_message(message.chat.id, "Please enter the username:")
    bot.register_next_step_handler(msg, process_username_step, bot)

def process_username_step(message, bot):
    try:
        chat_id = message.chat.id
        username = message.text
        
        if user_exists(username):
            bot.send_message(chat_id, "❌ Error: Username already exists!")
            return
            
        msg = bot.send_message(message.chat.id, "Please enter the password:")
        bot.register_next_step_handler(msg, process_password_step, username, bot)
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)}")

def process_password_step(message, username, bot):
    try:
        chat_id = message.chat.id
        password = message.text
        
        msg = bot.send_message(message.chat.id, "Input Expired days!")
        bot.register_next_step_handler(msg, process_expiry_step, username, password, bot)
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)}")

def process_expiry_step(message, username, password, bot):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    
    markup.add(sub1)

    try:
        chat_id = message.chat.id
        days = message.text
        
        if not days.isdigit():
            bot.send_message(chat_id, "❌ Error: Please enter a valid number of days")
            return
            
        days = int(days)
        expiry_date = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
        
        create_user(username, password, expiry_date)
        actual_expiry = get_expiry_date(username)
        save_account_info(username, password, actual_expiry)
        
        account_info = format_account_info(username, password, actual_expiry)
        bot.send_message(chat_id, account_info, reply_markup=markup, parse_mode='HTML') 
        
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)}")