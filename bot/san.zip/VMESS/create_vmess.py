import telebot
import uuid
import json
import base64
import subprocess
import random
import string
from datetime import datetime, timedelta
from telebot import types


def is_positive_integer(value):
    try:
        num = int(value)
        return num > 0
    except ValueError:
        return False

def generate_random_suffix(length=4):
    """Generate a random alphanumeric suffix to prevent duplicate usernames"""
    chars = string.ascii_lowercase + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

def check_username_exists(username):
    """Check if username already exists in config"""
    username = username.lower()
    config_file = "/etc/xray/config.json"
    try:
        with open(config_file, 'r') as f:
            content = f.read()
            return f'"email": "{username}"' in content
    except FileNotFoundError:
        return False

def build_vmess(user, host, uuid, proto):
    user_lower = user.lower()  # Convert username to lowercase
    config = {
        "v": "2",
        "ps": f"{user_lower}-{proto}",  # Use lowercase username
        "add": host,
        "port": "443" if proto in ["TLS", "gRPC"] else "80",
        "id": uuid,
        "aid": "0",
        "net": "ws" if proto in ["TLS", "WS"] else "grpc",
        "type": "none" if proto in ["TLS", "WS"] else "gun",
        "host": host,
        "path": "/vmess" if proto in ["TLS", "WS"] else "/vmess-grpc",
        "tls": "tls" if proto in ["TLS", "gRPC"] else "",
        "sni": host if proto in ["TLS", "gRPC"] else ""
    }
    return base64.b64encode(json.dumps(config).encode()).decode()

def add_to_config(user, uuid, days):
    user_lower = user.lower()  # Convert username to lowercase
    today = datetime.now().strftime("%Y-%m-%d")
    exp_date = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
    new_entry = f'{{"id": "{uuid}", "alterId": 0, "email": "{user_lower}"}},'  # Use lowercase username
    comment_line = f"## {user_lower} {exp_date}"  # Use lowercase username
    config_file = "/etc/xray/config.json"
    
    # Create a temporary file with the new content
    temp_content = f"{comment_line}\n{new_entry}\n"
    
    # Add to VMESS section
    subprocess.run([
        'sed', '-i', r'/\/\/ VMESS$/r /dev/stdin', config_file
    ], input=temp_content.encode())
    
    # Add to VMESS-GRPC section
    subprocess.run([
        'sed', '-i', r'/\/\/ VMESS-GRPC$/r /dev/stdin', config_file
    ], input=temp_content.encode())
    
    return exp_date

def set_ip_limit(user, limit):
    user_lower = user.lower()  # Convert username to lowercase
    limit_file = "/etc/xray/limitip/clients_limit.conf"
    with open(limit_file, 'a') as f:
        f.write(f"{user_lower}={limit}\n")

def create_vmess(bot, message):
    msg = bot.send_message(message.chat.id, "Input username!")
    bot.register_next_step_handler(msg, process_username_step, bot)

def process_username_step(message, bot):
    try:
        user = message.text.strip()
        # Check if username exists
        if check_username_exists(user):
            # Add random suffix if username exists
            random_suffix = generate_random_suffix()
            user = f"{user}-{random_suffix}"
            bot.send_message(message.chat.id, f"Username already exists. Appended random suffix: {user}")
        
        msg = bot.send_message(message.chat.id, f"Input Expired days!")
        bot.register_next_step_handler(msg, process_days_step, user, bot)  # Pass the potentially modified username
    except Exception as e:
        bot.reply_to(message, f'Error: {str(e)}')

def process_days_step(message, user, bot):
    try:
        days = message.text.strip()
        if not is_positive_integer(days):
            bot.send_message(message.chat.id, "Masa aktif harus angka positif!")
            return
        msg = bot.send_message(message.chat.id, f"Input limit IP!")
        bot.register_next_step_handler(msg, process_limit_step, user, int(days), bot)
    except Exception as e:
        bot.reply_to(message, f'Error: {str(e)}')

def process_limit_step(message, user, days, bot):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    
    markup.add(sub1)

    try:
        limit = message.text.strip()
        if not is_positive_integer(limit):
            bot.send_message(message.chat.id, "Limit IP harus angka positif!")
            return

        # Generate UUID
        new_uuid = str(uuid.uuid4())

        # Get host
        with open('/etc/xray/domain', 'r') as f:
            host = f.read().strip()

        # Add to config (username already lowercase)
        exp_date = add_to_config(user, new_uuid, days)

        # Set IP limit (username already lowercase)
        set_ip_limit(user, limit)

        # Generate links (username will be converted in build_vmess)
        link_tls = build_vmess(user, host, new_uuid, "TLS")
        link_ws = build_vmess(user, host, new_uuid, "WS")
        link_grpc = build_vmess(user, host, new_uuid, "gRPC")

        # Save to history
        history_file = f"/etc/xray/history/vmess-{user.lower()}"  # Filename in lowercase
        history_content = f"""✅ VMess Account Berhasil Dibuat
Username : {user}
Expired : {exp_date}
Limit IP : {limit}
-----------------------------------------------
UUID: {new_uuid}
Host: {host}
-----------------------------------------------
1. WebSocket + TLS (Port 443)
vmess://{link_tls}

2. WebSocket (tanpa TLS, Port 80)
vmess://{link_ws}

3. gRPC (Port 443)
vmess://{link_grpc}
-----------------------------------------------"""
        subprocess.run(['mkdir', '-p', '/etc/xray/history'])
        with open(history_file, 'w') as f:
            f.write(history_content)

        # Restart xray
        subprocess.run(['systemctl', 'restart', 'xray'])

        # Send results to user (display original case in message)
        result_message = f"""✅ VMess Account Berhasil Dibuat
Username : {user}
Expired : {exp_date}
Limit IP : {limit}
-----------------------------------------------
UUID: <code>{new_uuid}</code>
Host: {host}
-----------------------------------------------
1. WebSocket + TLS (Port 443)
<code>vmess://{link_tls}</code>

2. WebSocket (tanpa TLS, Port 80)
<code>vmess://{link_ws}</code>

3. gRPC (Port 443)
<code>vmess://{link_grpc}</code>
-----------------------------------------------"""
        bot.send_message(message.chat.id, result_message, reply_markup=markup, parse_mode='HTML')
    except Exception as e:
        bot.reply_to(message, f'Error: {str(e)}')