import telebot
import os
from telebot import types


def detail_vless(bot, message):
    folder = "/etc/xray/history/"
    
    if not os.path.exists(folder):
        bot.reply_to(message, "❌ Error: Folder history tidak ditemukan!")
        return
    
    try:
        # Mencari file yang diawali dengan 'vless-' (untuk akun VLESS)
        files = [f for f in os.listdir(folder) if f.startswith('vless-') and os.path.isfile(os.path.join(folder, f))]
        
        if not files:
            bot.reply_to(message, "❌ Tidak ada akun VLESS yang ditemukan.")
            return
            
        # Membuat daftar akun bernomor
        account_list = "\n".join([f"  {i}. {filename[6:]}" for i, filename in enumerate(files, 1)])
        
        response = "┌──────────────────┐\n"
        response += "   .:: DETAIL AKUN VLESS ::. \n"
        response += "└──────────────────┘\n"
        response += account_list + "\n"
        response += "└──────────────────┘\n"
        response += "Input user number to select! \n"

        # Mengirim daftar sebagai pesan
        msg = bot.edit_message_text(
                  chat_id=message.chat.id,
                  message_id=message.message_id,
                  text=response,
                  parse_mode='HTML') 
        
        # Mendaftarkan handler untuk langkah selanjutnya
        bot.register_next_step_handler(msg, process_account_selection, files, bot)
        
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)}")

def process_account_selection(message, files, bot):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    markup.add(sub1)

    try:
        # Mendapatkan pilihan user
        selection = message.text.strip()
        
        if not selection.isdigit():
            bot.reply_to(message, "❌ Input tidak valid! Harap masukkan angka.")
            return
            
        index = int(selection) - 1
        
        if 0 <= index < len(files):
            folder = "/etc/xray/history/"
            selected_file = os.path.join(folder, files[index])
            
            # Membaca isi file
            with open(selected_file, 'r') as f:
                content = f.read()
            
            
            # Mengirim konten (pertimbangkan untuk membagi jika terlalu panjang)
            bot.send_message(message.chat.id, content, reply_markup=markup)
        else:
            bot.reply_to(message, "❌ Nomor tidak valid! Silakan pilih nomor dari daftar.")
            
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)}")