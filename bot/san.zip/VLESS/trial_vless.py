import telebot
import uuid
import subprocess
from telebot import types
from datetime import datetime, timedelta
import random
import string

def generate_random_text(length=8):
    """Generate random text for trial username"""
    letters = string.ascii_letters
    return ''.join(random.choice(letters) for i in range(length))

def get_host():
    try:
        with open('/etc/xray/domain', 'r') as f:
            return f.read().strip()
    except FileNotFoundError:
        return "example.com"  # Fallback if domain file not found

def add_limit_ip(user, limit):
    file_path = "/etc/xray/limitip/clients_limit.conf"
    try:
        with open(file_path, 'a') as f:
            f.write(f"{user}={limit}\n")
        return True
    except Exception as e:
        print(f"Error adding limit IP: {e}")
        return False

def add_to_config(user, new_uuid, exp_date):
    config_file = "/etc/xray/config.json"
    new_entry = f'{{"id": "{new_uuid}", "email": "{user}"}},'
    comment_line = f"#? {user} {exp_date}"
    
    try:
        # Backup the config file first
        subprocess.run(['cp', config_file, f"{config_file}.bak"], check=True)
        
        # Properly escaped sed commands
        sed_vless_cmd = f'sed -i \'/\\/\\/ VLESS$/a {comment_line}\\n{new_entry}\' {config_file}'
        sed_grpc_cmd = f'sed -i \'/\\/\\/ VLESS-GRPC$/a {comment_line}\\n{new_entry}\' {config_file}'
        
        subprocess.run(sed_vless_cmd, shell=True, check=True)
        subprocess.run(sed_grpc_cmd, shell=True, check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error modifying config: {e}")
        # Restore backup if needed
        subprocess.run(['cp', f"{config_file}.bak", config_file], check=True)
        return False

def save_account_info(user, exp_date, limit, new_uuid, host, links):
    history_path = f"/etc/xray/history/vless-{user}"
    try:
        with open(history_path, 'w') as f:
            f.write(f"✅ Account VLess Berhasil Dibuat\n")
            f.write(f"Username     : {user}\n")
            f.write(f"Expired      : {exp_date}\n")
            f.write(f"Limit IP     : {limit}\n")
            f.write("-----------------------------------------------\n")
            f.write(f"UUID: {new_uuid}\n")
            f.write(f"Host: {host}\n")
            f.write("-----------------------------------------------\n")
            f.write("1. WebSocket + TLS (Port 443)\n")
            f.write(f"{links['tls']}\n\n")
            f.write("2. WebSocket (tanpa TLS, Port 80)\n")
            f.write(f"{links['ws']}\n\n")
            f.write("3. gRPC (Port 443)\n")
            f.write(f"{links['grpc']}\n")
            f.write("-----------------------------------------------\n")
        return True
    except Exception as e:
        print(f"Error saving account info: {e}")
        return False

def restart_xray():
    try:
        subprocess.run(['systemctl', 'restart', 'xray'], check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error restarting Xray: {e}")
        return False


def trial_vless(bot, message):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    
    markup.add(sub1)
    
    random_text = generate_random_text()
    user = f"Trial-{random_text}"
    days = 1
    limit = 1

    chat_id = message.chat.id
     
    # Generate account details
    new_uuid = str(uuid.uuid4()).lower()
    host = get_host()
    today = datetime.now().strftime("%Y-%m-%d")
    exp_date = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
    
    # Create links
    remark_tls = f"{user}-TLS"
    remark_ws = f"{user}-WS"
    remark_grpc = f"{user}-gRPC"
    
    links = {
        'tls': f"vless://{new_uuid}@{host}:443?path=/vlessws&security=tls&encryption=none&type=ws&host={host}&sni={host}#{remark_tls}",
        'ws': f"vless://{new_uuid}@{host}:80?path=/vless-grpc&security=none&encryption=none&type=ws&host={host}#{remark_ws}",
        'grpc': f"vless://{new_uuid}@{host}:443?mode=gun&security=tls&encryption=none&type=grpc&serviceName=/vless-grpc&host={host}&sni={host}#{remark_grpc}"
    }
    
    
    # Add to config files
    success = True
    success &= add_limit_ip(user, limit)
    success &= add_to_config(user, new_uuid, exp_date)
    success &= save_account_info(user, exp_date, limit, new_uuid, host, links)
    success &= restart_xray()
    
    
    if not success:
        bot.send_message(chat_id, "Gagal membuat akun. Silakan coba lagi atau periksa log.")
        return
    
    # Send account details
    response = f"""
✅ Account VLess Berhasil Dibuat
Username     : {user}
Expired      : {exp_date}
Limit IP     : {limit}
-----------------------------------------------
UUID: <code>{new_uuid}</code>
Host: {host}
-----------------------------------------------
1. WebSocket + TLS (Port 443)
<code>{links['tls']}</code>

2. WebSocket (tanpa TLS, Port 80)
<code>{links['ws']}</code>

3. gRPC (Port 443)
<code>{links['grpc']}</code>
-----------------------------------------------
⚠️ Akun trial hanya berlaku 1 hari dan limit 1 IP
"""
    
    bot.edit_message_text(
                  chat_id=message.chat.id,
                  message_id=message.message_id,
                  text=response,
                  reply_markup=markup,
                  parse_mode='HTML') 


