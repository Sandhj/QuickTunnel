import os
import telebot
from telebot import types

def detail_ssh(bot, message):
    folder = "/etc/xray/history/"
    
    # Check if folder exists
    if not os.path.isdir(folder):
        bot.reply_to(message, "Error: Folder not found!")
        return
    
    # Get all ssh- files
    try:
        files = [f for f in os.listdir(folder) if f.startswith('ssh-') and os.path.isfile(os.path.join(folder, f))]
    except Exception as e:
        bot.reply_to(message, f"Error reading directory: {str(e)}")
        return
    
    if not files:
        bot.reply_to(message, "No SSH account files found.")
        return
    
    # Create numbered list
    response = "┌──────────────────┐\n"
    response += "    .:: DETAIL SSH ACCOUNT ::.   \n"
    response += "└──────────────────┘\n"
    for i, filename in enumerate(files, 1):
        display_name = filename[4:]  # Remove 'ssh-' prefix
        response += f"  {i}. {display_name}\n"
    
    response += "└──────────────────┘\n"
    response += "Input number user to select!:"
    
    msg = bot.edit_message_text(
                  chat_id=message.chat.id,
                  message_id=message.message_id,
                  text=response,
                  parse_mode='HTML') 

    bot.register_next_step_handler(msg, lambda m: handle_ssh_selection(bot, m, files))

def handle_ssh_selection(bot, message, files):
    markup = types.InlineKeyboardMarkup(row_width=1)
    sub1 = types.InlineKeyboardButton("KEMBALI", callback_data='menu_utama')
    
    markup.add(sub1)

    try:
        folder = "/etc/xray/history/"
        
        if not files:
            bot.send_message(message.chat.id, "No SSH accounts available. Please use /list again.")
            return
        
        try:
            selected_num = int(message.text)
            if 1 <= selected_num <= len(files):
                selected_file = files[selected_num - 1]
                file_path = os.path.join(folder, selected_file)
                
                try:
                    with open(file_path, 'r') as f:
                        content = f.read()
                    
                    # Format the response
                    response = content
                    
                    bot.send_message(message.chat.id, f"{response}", reply_markup=markup)
         
                except Exception as e:
                    bot.send_message(message.chat.id, f"Error reading file: {str(e)}")
            else:
                bot.send_message(message.chat.id, "Invalid number. Please select a number from the list.")
        except ValueError:
            bot.send_message(message.chat.id, "Please enter a valid number.")
        
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {str(e)}")